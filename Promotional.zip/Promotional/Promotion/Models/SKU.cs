﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Promotion.Models

{
    public enum Scenerios
    {
        A, B, C,
    }
    public class SKU


    {
        public int SKUID { get; set; }
        public int SKUname { get; set; }
        public int SKU_Pricing { get; set; }


        public Scenerios? Scenerios { get; set; }
    }
};